
# tools/plot_bsim3_csv.py - read CSV dumped by ngspice and plot figures
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

root = os.path.dirname(os.path.dirname(__file__))
csv_dir = os.path.join(root, "csv")
fig_dir = os.path.join(root, "Edusemi-v4x/chapter4_mos_characteristics/figures")
os.makedirs(fig_dir, exist_ok=True)

# 1) Vg-Id (two nodes), CSV columns: V(g1), -I(VDD1), -I(VDD2), @M018[g_m], @M013[g_m]
vgid = pd.read_csv(os.path.join(csv_dir, "vg_id_bsim3.csv"), delim_whitespace=True, comment='*', header=None)
vgid.columns = ["Vg1","Id018","Id013","gm018","gm013"]

plt.figure()
plt.plot(vgid["Vg1"], 1e3*vgid["Id018"], label="NMOS 0.18µm")
plt.plot(vgid["Vg1"], 1e3*vgid["Id013"], label="NMOS 0.13µm")
plt.xlabel("Gate Voltage Vg [V]")
plt.ylabel("Drain Current Id [mA/µm]")
plt.title("Vg–Id Characteristics (BSIM3, W=1µm normalized)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(fig_dir, "mosfet_vg_id_018_013.png"), dpi=300)
plt.close()

# 2) Vd-Id (0.18um, Vg stepped), columns: V(g) V(d) -I(VDD) gm
vdid = pd.read_csv(os.path.join(csv_dir, "vd_id_bsim3.csv"), delim_whitespace=True, comment='*', header=None)
vdid.columns = ["Vg","Vd","Id018","gm018"]
for vgval in sorted(vdid["Vg"].unique()):
    sel = vdid[vdid["Vg"]==vgval]
    plt.plot(sel["Vd"], 1e3*sel["Id018"], label=f"Vg={{vgval:.1f}}V")
plt.xlabel("Drain Voltage Vd [V]")
plt.ylabel("Drain Current Id [mA/µm]")
plt.title("Vd–Id Characteristics (BSIM3, 0.18µm, W=1µm)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(fig_dir, "mosfet_vd_id_018_013.png"), dpi=300)
plt.close()

# 3) Vg-Cg (cgg from BSIM3), columns: V(g1) cgg018 V(g2) cgg013
vgcg = pd.read_csv(os.path.join(csv_dir, "vg_cg_bsim3.csv"), delim_whitespace=True, comment='*', header=None)
vgcg.columns = ["Vg018","Cgg018","Vg013","Cgg013"]
plt.figure()
plt.plot(vgcg["Vg018"], 1e15*vgcg["Cgg018"], label="0.18µm")
plt.plot(vgcg["Vg013"], 1e15*vgcg["Cgg013"], label="0.13µm")
plt.xlabel("Gate Voltage Vg [V]")
plt.ylabel("Gate Capacitance Cg [fF/µm]")
plt.title("Vg–Cg Characteristics (BSIM3, W=1µm normalized)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(fig_dir, "mosfet_vg_cg_018_013.png"), dpi=300)
plt.close()

print("Saved figures to:", fig_dir)
